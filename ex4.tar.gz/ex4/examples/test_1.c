int f(int x, int y) {
    int z := x + y;
    return z;
}

void main() {
    int z := f(1, 2);
    PrintInt(z);
}
