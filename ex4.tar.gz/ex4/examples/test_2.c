string z := "abcd";

void main() {
    PrintString(z);
}
