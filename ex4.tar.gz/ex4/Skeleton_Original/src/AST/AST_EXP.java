package AST;

import TYPES.*;
import TEMP.*;

public abstract class AST_EXP extends AST_Node
{
	public TYPE SemantMe()
	{
		return null;
	}
	public TEMP IRme()
	{
		return null;
	}
}
