package AST;

import TYPES.*;

public abstract class AST_EXP_VAR extends AST_EXP
{
	public TYPE SemantMe()
	{
		return null;
	}
}
