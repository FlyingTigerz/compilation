package AST;

import TYPES.*;

public abstract class AST_DEC extends AST_Node
{
	public TYPE SemantMe()
	{
		return null;
	}
}
