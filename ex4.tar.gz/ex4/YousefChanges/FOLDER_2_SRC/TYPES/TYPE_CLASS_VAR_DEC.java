package TYPES;

public class TYPE_CLASS_VAR_DEC
{
	public TYPE t;
	public String name;
	
	public TYPE_CLASS_VAR_DEC(TYPE t, String name)
	{
		this.t = t;
		this.name = name;
	}
}
